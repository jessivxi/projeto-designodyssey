import React from 'react'

export default function Teste() {
  return (
    <div>teste</div>
  )
}
